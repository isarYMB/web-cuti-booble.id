@extends('layouts/index')

@section('content')
    <div class="main-content">
        <h1>Hello</h1>
    </div>
@endsection
