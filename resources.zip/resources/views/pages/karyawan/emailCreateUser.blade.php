<h2>{{ $isi_email['title'] }}</h2>
<p>{{ $isi_email['body'] }}</p>
<p>Email: {{ $isi_email['email'] }}</p>
<p>Password: {{ $isi_email['password'] }}</p>