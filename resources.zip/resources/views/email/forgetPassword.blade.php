<h1>Mereset Password Akun Pengajuan Cuti Booble.id</h1>
   
Silahkan klik link di bawah ini untuk mereset password akun pengajuan cuti Booble.id anda:
<a href="{{ route('reset.password.get', $token) }}">Reset Password</a>